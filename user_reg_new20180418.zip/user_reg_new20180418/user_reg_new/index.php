<!DOCTYPE html>
<html class="no-js">
    
    <head>
        <title><?php echo $username; ?></title>
        <!-- Bootstrap -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="assets/styles.css" rel="stylesheet" media="screen">
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        
    </head>
    
    <body class="body">
        <script src="bootstrap/js/jquery-1.9.1.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/scripts.js"></script>
		<div class='mainContent'>
			<div class='content'>
				<article class='bottomcontent'>
					<header>
						<h3>Windows 连接 VPN 方法一[IKEv2]</h3>
					</header>
					<hr>
					<content>
						<p>第一步：<a href="inportca.php">［导入证书］win7/8/10 首先点击这里导入VPN证书</a></p>
						<p>第二步：［创建VPN连接］根据您的操作系统类型，点击下面的链接，按照提示进行操作</p>
						<ul class="list">
							<li><a href="win7.php">Windows 7/8配置VPN连接(IKEV2)</a></li>
							<li><a href="win10.php">Windows 10配置VPN连接(IKEV2)</a></li>
							<li><a href="winxp.php">Windows XP配置VPN连接</a></li>
						</ul>
					</content>
				</article>
                <article class='bottomcontent'>
					<header>
						<h3>Windows 连接 VPN 方法二[openvpn]</h3>
					</header>
					<hr>
					<content>
						<p><a href="winovpn.php">Windows通过客户端连接VPN</a></p>
					</content>
				</article>
				<article class='bottomcontent'>
					<header>
						<h3>苹果系统连接 VPN 方法一[ipsec]</h3>
					</header>
					<hr>
					<content>
						<ul class="list">
							<li><a href="osx.php">OS X（苹果笔记本一体机）配置VPN</a></li>
							<li><a href="iphone.php">iPhone/iPad设置VPN连接</a></li>
						</ul>
					</content>
				</article>
                				<article class='bottomcontent'>
					<header>
						<h3>苹果系统连接 VPN 方法二[IKEv2]</h3>
					</header>
					<hr>
					<content>
						<ul class="list">
							<li><a href="osxovpn.php">OS X（苹果笔记本一体机）配置VPN</a></li>
							<li><a href="iphoneovpn.php">iPhone/iPad设置VPN连接</a></li>
						</ul>
					</content>
				</article>
				
			</div>
		</div>
		<aside class='top-sidebar sidebar'>
			<article>
				<h3><a href="index.php">返回首页</a></h3>
				<hr>
			</article>
		</aside>
		<footer class='mainFooter'>
			<p>Ezio 网络加速</p>
		</footer>

 
</body>

</html>
