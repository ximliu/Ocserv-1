<!DOCTYPE html>
<html class="no-js">
    
    <head>
        <title><?php echo $username; ?></title>
        <!-- Bootstrap -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="assets/styles.css" rel="stylesheet" media="screen">
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        
    </head>
    
    <body class="body">
        <script src="bootstrap/js/jquery-1.9.1.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/scripts.js"></script>
		<div class='mainContent'>
			<div class='content'>
				<article class='topcontent'>
					<header>
						<h3>Windows 7/8/10 导入VPN证书</h3>
					</header>
					<hr>
					<content>
						<p>1.（<a href="client.zip" target="_blank">点击下载</a>）证书压缩包（2018年2月12号更新），解压证书（client.cert.p12）存放于任意位置，然后点击运行命令&rdquo;mmc&rdquo;</p>
						<p><img src="/images/win1.jpg" alt="" /></p>
						<p>2.点击文件–添加或删除管理单元，在可用管理单元中选择&ldquo;证书&rdquo;，添加，再选择计算机帐户，点本地计算机完成，确定。</p>
						<p><img src="/images/win2.jpg" /></p>
                        <p><img src="/images/win3.jpg" /></p>
						<p><img src="/images/win4.jpg" /></p>
                        <p><img src="/images/inport_ca_b0.png" /></p>
						<p>3.右键点击受信任的根证书颁发机构的证书–所有任务–导入，再点下一步，点击浏览选择在第一步中下载的证书文件，然后再点下一步，证书存储在&ldquo;受信任的根证书颁发机构&rdquo;，然后再点下一步完成。</p>
						<p><img src="/images/win6.jpg" alt="" /> <img src="/images/win7.jpg" alt="" /></p>
                        <p><img src="/images/inport_ca_b3.png" alt="" /></p>
                        <p><img src="/images/inport_ca_b1.png" alt="" /></p>
                        <p><img src="/images/win8.png" alt="" /></p>
						<p>注意，有人说在这里找不到刚才下载的证书文件，，在打开的框里，右下角处，&ldquo;打开（O）&rdquo;的上面选择&ldquo;所有文件（*.*）&rdquo;这样就可以找到了。</p>
						<p><img src="/images/win9.jpg" alt="" /></p>
						<p>这里密码为空</p>
						<p><img src="/images/win10.jpg" alt="" /> <img src="/images/win11.jpg" alt="" /></p>
						<p>windows导入证书到此完成，请到<a href="index.php">首页</a>查看如何配置VPN连接</p>
					</content>
				</article>
			</div>
		</div>
		<aside class='top-sidebar sidebar'>
			<article>
				<h3><a href="index.php">返回首页</a></h3>
				<hr>
			</article>
		</aside>
		<footer class='mainFooter'>
			<p>Ezio 网络加速</p>
		</footer>

 
</body>

</html>
