<?php
require_once 'class.user.php';
$user_home = new USER();
?>
<!DOCTYPE html>
<html class="no-js">
    
    <head>
        <title><?php echo $username; ?></title>
        <!-- Bootstrap -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="assets/styles.css" rel="stylesheet" media="screen">
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        
    </head>
    
    <body class="body">
        <script src="bootstrap/js/jquery-1.9.1.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/scripts.js"></script>
		<div class='mainContent'>
			<div class='content'>
				<article class='topcontent'>
					<header>
						<h3>Windows 7/8 配置VPN连接</h3>
					</header>
					<hr>
					<content>
					<p>1.下载VPN客户端，请根据您的操作类型下载，如果不清楚操作系统类型，请<a href="https://zhidao.baidu.com/question/437166357.html" target="_blank" rel="noopener">点击这里</a>查看</p>
					<ul>
					  <li>winxp操作系统 <a href="/images/sslvpn-install-1.0.0-i686-XP.exe">点击这里</a>下载</li>
					  <li>win7／win8／win10 － 32位操作系统<a href="/images/sslvpn-install-1.0.0-i686.exe">点击这里</a>下载</li>
 					  <li>win7／win8／win10 － 64位操作系统<a href="/images/sslvpn-install-1.0.0-x86_64.exe">点击这里</a>下载</li>
					  <li>下载完成后执行默认安装</li>
					</ul>
					<p>2. <a href="/openvpnclient.zip">点击这里</a>下载VPN证书文件，并减压缩，拷贝减压后的，ca.crt、client.ovpn文件到C:\Program Files\SSLVPN\config\目录下，覆盖原来的文件</p>
                    <p>注意：64为系统的安装目录是C:\Program Files (x86)\SSLVPN\config\</p>
					<p>3. 双击桌面右下角图标,如图<br />
					  <img src="/images/openvpn4.png" alt="" /></p>
					<p>4. 在出现的下面对话框中输入VPN用户名和密码<br />
					  <img src="/images/openvpn5.png" alt="" /></p>
					<p>5. 连接成功显示如下信息<br />
					  <img src="/images/openvpn6.png" alt="" /></p>	
											
					</content>
				</article>
			</div>
		</div>
		<aside class='top-sidebar sidebar'>
			<article>
				<h3><a href="index.php">返回首页</a></h3>
				<hr>
			</article>
		</aside>
		<footer class='mainFooter'>
			<p>Ezio 网络加速</p>
		</footer>

 
</body>

</html>
