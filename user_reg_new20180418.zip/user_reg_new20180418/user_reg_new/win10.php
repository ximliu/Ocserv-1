<?php
require_once 'class.user.php';
$user_home = new USER();
?>
<!DOCTYPE html>
<html class="no-js">
    
    <head>
        <title><?php echo $username; ?></title>
        <!-- Bootstrap -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="assets/styles.css" rel="stylesheet" media="screen">
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        
    </head>
    
    <body class="body">
        <script src="bootstrap/js/jquery-1.9.1.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/scripts.js"></script>
		<div class='mainContent'>
			<div class='content'>
				<article class='topcontent'>
					<header>
						<h3>Windows 7/8 配置VPN连接</h3>
					</header>
					<hr>
					<content>
						<p><strong>win7/8/10 首先点击<a href="inportca.php">这里导入VPN证书</a></strong>，如果已导入，请按照下面操作创建VPN连接。</p>
						<p>第一步：WINDOWS 10添加VPN连接。</p>
						<p><img src="/images/win-ikev2-1.png" alt="" /></p>
						<p><img src="/images/win-ikev2-2.png" alt="" /></p>
						<p>第二步：按照图中的示例输入和选择各类参数，服务器名地址为：<b style="color:red"><?php echo $user_home->pubIP; ?></b></p>
						<p>帐户名和VPN登录密码。</p>
						<p><img src="/images/win-ikev2-3.png" alt="" /></p>
						<p>第三步：连接之前还需要修改VPN连接的加密选项，点击&lsquo;更改适配器选项&rsquo; -&gt;右击属性-&gt;选择安全标签，出现下面的界面，设置与图中一样即可</p>
						<p><img src="/images/win-ikev2-4.png" alt="" /></p>
						<p><img src="/images/C19_PDP@IEE3BU0LZQ.png" alt="" width="655" height="491" /></p>
						<p><img src="/images/IK0R@GWV@ERQYAUR4FKD.jpg" alt="" width="446" height="511" /><br />
						  <img src="/images/6IGC07797NOAS_VQ3S.png" alt="" width="447" height="550" /></p>
						<p>点击确定。</p>
						<p>第四步：点击连接，然后按照图中的示例操作即可。</p>
						<p><img src="/images/win-ikev2-5.png" alt="" /></p>
						<p><img src="/images/win-ikev2-6.png" alt="" /></p>
						<p><img src="/images/win-ikev2-7.png" alt="" /></p>
						<p><img src="/images/win-ikev2-8.png" alt="" /></p>
					</content>
				</article>
			</div>
		</div>
		<aside class='top-sidebar sidebar'>
			<article>
				<h3><a href="index.php">返回首页</a></h3>
				<hr>
			</article>
		</aside>
		<footer class='mainFooter'>
			<p>Ezio 网络加速</p>
		</footer>

 
</body>

</html>
