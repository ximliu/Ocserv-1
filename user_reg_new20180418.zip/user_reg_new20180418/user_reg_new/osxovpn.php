<?php
require_once 'class.user.php';
$user_home = new USER();

//在class.user.php中定义了获取共享密钥
$ipsecpsk = $user_home->ipsec_config_set();
//echo $ipsecpsk;

?>
<!DOCTYPE html>
<html class="no-js">
    
    <head>
        <title><?php echo $username; ?></title>
        <!-- Bootstrap -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="assets/styles.css" rel="stylesheet" media="screen">
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        
    </head>
    
    <body class="body">
        <script src="bootstrap/js/jquery-1.9.1.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/scripts.js"></script>
		<div class='mainContent'>
			<div class='content'>
				<article class='topcontent'>
					<header>
						<h3>苹果操作系统（OS X）配置IKEv2连接</h3>
					</header>
					<hr>
					<content>
                        <p>1、<a href="ca.zip">点击这里</a>下载证书,并减压缩</p>
                        <p>2、导入证书</p>
                            <p>右击证书，打开方式选择“钥匙串访问（默认）”</p>
                            <p><img src="/images/osx_inportca01.png" /></p>
                            <p>双击证书，在弹出的对话框中，点击信任左侧的尖头，使用证书时选择始终信任</p>
                            <p><img src="/images/osx_inportca02.png" /></p>
                            <p>点击左上角的关闭后，将提示输入您osx系统密码，输入之后点击确定</p>
                            <p><img src="/images/osx_inportca03.png" /></p>
						<p>3、进入系统偏好设置－网络</p>
						<p><img src="/images/mac_ipsec_02.jpg" /></p>
						<p>4、创建一个新服务（点列表下方的+），在弹出的窗口中VPN类型选择IKEv2，然后点击创建</p>
						<p><img src="/images/add_vpn3.png"  /></p>
						<p>5、填写服务器信息</p>
                            <ul class="list">
                                <li>服务器:<b style="color:red"><?php echo $user_home->pubIP; ?></b></li>
                                <li>远程ID:<b style="color:red"><?php echo $user_home->pubIP; ?></b></li>
                                <li>本地ID - 不用填，留空</li>
                            </ul>
						<p>6、然后点击鉴定设置，在弹出的窗口中输入用户名和 密码。最后点击右下角的应用程序</p>
						<p> <img src="/images/enter_username_password1.png" /></p>
						<p>7、到这里VPN设置完成，可以你点击应用，之后点击连接来连接到对应的VPN</p>
					</content>
				</article>
			</div>
		</div>
		<aside class='top-sidebar sidebar'>
			<article>
				<h3><a href="index.php">返回首页</a></h3>
				<hr>
			</article>
		</aside>
		<footer class='mainFooter'>
			<p>Ezio 网络加速</p>
		</footer>

 
</body>

</html>
