<?php
require_once 'class.user.php';
$user_home = new USER();
?>
<!DOCTYPE html>
<html class="no-js">
    
    <head>
        <title><?php echo $username; ?></title>
        <!-- Bootstrap -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="assets/styles.css" rel="stylesheet" media="screen">
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        
    </head>
    
    <body class="body">
        <script src="bootstrap/js/jquery-1.9.1.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/scripts.js"></script>
		<div class='mainContent'>
			<div class='content'>
				<article class='topcontent'>
					<header>
						<h3>Windows 7/8 配置VPN连接</h3>
					</header>
					<hr>
					<content>
						<p>win7/8/10 首先<a href="inportca.php">点击这里导入VPN证书</a>，如果已经导入，请按照下面操作创建VPN连接</p>
						<p>1. 依次点击 开始->控制面板->网络和共享中心->设置新的连接或网络</p>
						<p><image src="/images/135432W9R.jpg"></image></p>
						<p>2. 选择“连接到工作区”，点击“下一步”；</p>
						<p><image src="/images/135438chV.jpg"></image></p>
						<p>3. 如果已经存在其他连接，则在这一步选择“否，创建新连接”；如果没有，则这一步将被跳过；</p>
						<p><image src="/images/135441yU0.jpg"></image></p>
						<p>4. 选择“使用我的Internet连接（VPN）”，点击“下一步”;</p>
						<p><image src="/images/135444Ikb.jpg"></image></p>
						<p>5. 在“Internet地址”栏填写VPN服务器地址<b style="color:red"><?php echo $user_home->pubIP; ?></b>，请选择一条节点地址填入。“目标名称”随意填写，点击下一步;</p>
						<p><image src="images/vpndizhi.png"></image></p>
						<p>6. 填写你创建的VPN用户名和密码，点击“连接”，</p>
						<p><image src="/images/135450nlJ.jpg"></image></p>
						<p>7. 链接成功后在桌面右下角会有提示</p>
						<p><image src="/images/135452p93.jpg"></image></p>
						
											
					</content>
				</article>
			</div>
		</div>
		<aside class='top-sidebar sidebar'>
			<article>
				<h3><a href="index.php">返回首页</a></h3>
				<hr>
			</article>
		</aside>
		<footer class='mainFooter'>
			<p>Ezio 网络加速</p>
		</footer>

 
</body>

</html>
