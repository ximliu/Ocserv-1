<!DOCTYPE html>
<html class="no-js">
    
    <head>
        <title><?php echo $username; ?></title>
        <!-- Bootstrap -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="assets/styles.css" rel="stylesheet" media="screen">
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        
    </head>
    
    <body class="body">
        <script src="bootstrap/js/jquery-1.9.1.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/scripts.js"></script>
		<div class='mainContent'>
			<div class='content'>
				<article class='topcontent'>
					<header>
						<h3>Windows XP 配置VPN连接</h3>
					</header>
					<hr>
					<content>
						<p>1. <a href="/images/sslvpn-install-1.0.0-i686-XP.exe">点击这里</a>下载vpn连接客户端程序，并执行默认安装</p>
						<p>2. <a href="openvpnclient.zip">点击这里</a>下载VPN证书文件，并减压缩，拷贝减压后的，ca.crt、client.ovpn文件到C:\Program Files\SSLVPN\config\目录下，覆盖原来的文件</p>
						
						<!-- ><p>3. 下面方法介绍如何查找vpn客户端的安装配置目录</p>
						
						<p>第一步：找到桌面安装的sslvpn软件，右击点击属性，如下图<br /><image src="images/openvpn1.png"></image></p>
						
						<p>第二步：点击打开文件位置<br /><image src="images/openvpn2.png"></image></p>
						
						<p>第三步：找到config目录，如果是默认安装，目录为C:\Program Files\SSLVPN\config\ ，将上面复制的文件拷贝到这里，覆盖原来的文件<br /><image src="images/openvpn3.png"></image></p> -->
						
						<p>3. 双击桌面右下角图标,如图<br /><image src="images/openvpn4.png"></image></p>
						
						<p>4. 在出现的下面对话框中输入VPN用户名和密码（注册时填写的邮箱地址和密码）<br /><image src="images/openvpn5.png"></image></p>
						
						<p>5. 连接成功显示如下信息<br /><image src="images/openvpn6.png"></image></p>
									
					</content>
				</article>
			</div>
		</div>
		<aside class='top-sidebar sidebar'>
			<article>
				<h3><a href="index.php">返回首页</a></h3>
				<hr>
			</article>
		</aside>
		<footer class='mainFooter'>
			<p>Ezio 网络加速</p>
		</footer>

 
</body>

</html>
