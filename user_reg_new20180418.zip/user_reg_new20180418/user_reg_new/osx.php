<?php
require_once 'class.user.php';
$user_home = new USER();

//在class.user.php中定义了获取共享密钥
$ipsecpsk = $user_home->ipsec_config_set();
//echo $ipsecpsk;

?>
<!DOCTYPE html>
<html class="no-js">
    
    <head>
        <title><?php echo $username; ?></title>
        <!-- Bootstrap -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="assets/styles.css" rel="stylesheet" media="screen">
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        
    </head>
    
    <body class="body">
        <script src="bootstrap/js/jquery-1.9.1.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/scripts.js"></script>
		<div class='mainContent'>
			<div class='content'>
				<article class='topcontent'>
					<header>
						<h3>苹果操作系统（OS X）配置IPsecVPN连接</h3>
					</header>
					<hr>
					<content>
						<p>1、进入系统偏好设置－网络</p>
						<p><img src="/images/mac_ipsec_02.jpg" /></p>
						<p>2、创建一个新服务（点列表下方的+），之后点击&ldquo;创建&rdquo;</p>
						<p><img src="/images/mac_ipsec_03.jpg"  /></p>
						<p>接口：VPN<br />
						  VPN类型：Cisco IPsec<br />
						  服务名称：任意填写</p>
						<p><img src="/images/mac_ipsec_04.jpg"  /></p>
						<p> </p>
						<p>3、设置服务器地址:<b style="color:red"><?php echo $user_home->pubIP; ?></b>账户名称、密码</p>
						<p><img src="/images/mac_ipsec_05.png" /></p>
						<p>4、点击&ldquo;鉴定设置&rdquo;，填写&ldquo;共享的密钥为<b style="color:red"><?php echo $ipsecpsk;?></b>之后点击&ldquo;好&rdquo;，再点&ldquo;应用&rdquo;。</p>
						<p><img src="/images/mac_ipsec_06.png" /></p>
						<p>5、应用之后，点击连接</p>
						<p><img src="/images/mac_ipsec_07.png" /></p>
						<p>连接后状态如下图所示</p>
						<p><img src="/images/mac_ipsec_08.png" /></p>
						
											
					</content>
				</article>
			</div>
		</div>
		<aside class='top-sidebar sidebar'>
			<article>
				<h3><a href="index.php">返回首页</a></h3>
				<hr>
			</article>
		</aside>
		<footer class='mainFooter'>
			<p>Ezio 网络加速</p>
		</footer>

 
</body>

</html>
