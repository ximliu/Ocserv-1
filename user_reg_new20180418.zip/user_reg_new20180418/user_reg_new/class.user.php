<?php

class USER
{	

    	public $pubIP = '';
	
	//获取共享密钥函数，需要把/etc/strongswan/ipsec.secrets权限设置为o+r ,chmod o+x /etc/strongswan/
	public function ipsec_config_set()
	{
		if (file_exists("/etc/strongswan/ipsec.secrets"))
		{
		exec("cat /etc/strongswan/ipsec.secrets | grep ': PSK' | cut -f3 -d' '", $strongswanPSK, $key_return);
			if (!$key_return)
			{
				$strongswanPSK = trim($strongswanPSK[0]);
			}
		}
		return $strongswanPSK;
	}
	
}
?>
