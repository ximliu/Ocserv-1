<?php
require_once 'class.user.php';
$user_home = new USER();

//在class.user.php中定义了获取共享密钥
$ipsecpsk = $user_home->ipsec_config_set();
//echo $ipsecpsk;

?>
<!DOCTYPE html>
<html class="no-js">
    
    <head>
        <title><?php echo $username; ?></title>
        <!-- Bootstrap -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="assets/styles.css" rel="stylesheet" media="screen">
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        
    </head>
    
    <body class="body">
        <script src="bootstrap/js/jquery-1.9.1.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/scripts.js"></script>
		<div class='mainContent'>
			<div class='content'>
				<article class='topcontent'>
					<header>
						<h3>Iphone手机VPN连接</h3>
					</header>
					<hr>
					<content>
						<p>进入手机的&ldquo;设置&rdquo;，找到VPN，点击底部的&ldquo;添加VPN配置…&rdquo;，再按照下图的图示填写即可：</p>
						<p><img src="images/iphone-ipsec.png" alt="" /></p>
						<p>注：</p>
						<p>1、服务器 － 直接输入IP地址 <b style="color:red"><?php echo $user_home->pubIP; ?></b></p>
                        <p>2、帐户 － <b style="color:red">输入VPN账号</b></p>
                        <p>3、密码 － <b style="color:red">输入VPN密码</b></p>
						<p>4、密钥 － 输入小写的 <b style="color:red"><?php echo $ipsecpsk;?></b></p>
						
											
					</content>
				</article>
			</div>
		</div>
		<aside class='top-sidebar sidebar'>
			<article>
				<h3><a href="index.php">返回首页</a></h3>
				<hr>
			</article>
		</aside>
		<footer class='mainFooter'>
			<p>Ezio 网络加速/p>
		</footer>

 
</body>

</html>
