<?php
require_once 'class.user.php';
$user_home = new USER();

//在class.user.php中定义了获取共享密钥
$ipsecpsk = $user_home->ipsec_config_set();
//echo $ipsecpsk;

?>
<!DOCTYPE html>
<html class="no-js">
    
    <head>
        <title><?php echo $username; ?></title>
        <!-- Bootstrap -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="assets/styles.css" rel="stylesheet" media="screen">
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        
    </head>
    
    <body class="body">
        <script src="bootstrap/js/jquery-1.9.1.min.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/scripts.js"></script>
		<div class='mainContent'>
			<div class='content'>
				<article class='topcontent'>
					<header>
						<h3>Iphone手机VPN连接[IKEv2]</h3>
					</header>
					<hr>
					<content>
                        <p>1、<a href="ca.zip">点击这里</a>下载证书,并减压缩</p>
                        <p>2、导入证书</p>
                            <p>1)通过邮件发送解压缩后的证书文件到您的邮箱，并使用iphone上的邮件系统打开</p>
                            <p><img src="/images/iphone_ca01.jpg" /></p>
                            <p>2)在邮件中找到这份邮件的附件，并打开</p>
                            <p><img src="/images/iphone_ca02.jpg" /></p>
                            <p>3)点击安装</p>
                            <p><img src="/images/iphone_ca03.jpg" /></p>
                            <p>4)点击安装</p>
                            <p><img src="/images/iphone_ca04.jpg" /></p>
                            <p>5)点击安装</p>
                            <p><img src="/images/iphone_ca05.jpg" /></p>
                            <p>6)点击完成</p>
                            <p><img src="/images/iphone_ca06.jpg" /></p>
                            <p>3、配置VPN连接，打开设置，选择通用，再选择VPN。你将会看到下面的界面。</p>
                              <p><img src="/images/settings_vpn3.png" /></p>
                            <p>4、点击添加VPN配置，看到下面的界面， 类型选择IKEv2，然后填写详细信息。</p>
                                <ul>
                                    <li>描述 - 任何名字，比如“ikev2”</li>
                                    <li>服务器 - <b style="color:red"><?php echo $user_home->pubIP; ?></b></li>
                                    <li>远程ID - <b style="color:red"><?php echo $user_home->pubIP; ?></b></li>
                                    <li>本地ID - 不用填，留空</li>
                                    <li>用户名 - VPN用户名</li>
                                    <li>密码 - VPN密码</li>
                                </ul>
                            <p><img src="/images/fill_detail3.png" /></p>
                            <p>5、按下然后完成按钮。</p>
                            <p>6、新的VPN配置已经成功创建。</p>
                            <p><img src="/images/settings_vpn_with_new_vpn3.png" /></p>
                            <p>你现在可以连接到服务器了</p>
					</content>
				</article>
			</div>
		</div>
		<aside class='top-sidebar sidebar'>
			<article>
				<h3><a href="index.php">返回首页</a></h3>
				<hr>
			</article>
		</aside>
		<footer class='mainFooter'>
			<p>Ezio 网络加速</p>
		</footer>

 
</body>

</html>
