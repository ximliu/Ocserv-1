<?php
	if (file_exists("/etc/strongswan/ipsec.secrets"))
		{
		exec("cat /etc/strongswan/ipsec.secrets | grep ': PSK' | cut -f3 -d' '", $strongswanPSK, $key_return);
			if (!$key_return)
			{
				$strongswanPSK = trim($strongswanPSK[0]);
			}
		}
	else echo 'aaaaaa';
 echo $strongswanPSK;
?>
