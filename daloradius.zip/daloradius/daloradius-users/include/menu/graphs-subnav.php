
                                <ul id="subnav">
				<div id="logindiv" style="text-align: right;">
                                                <li><?php echo $l['menu']['Welcome'];?>, <?php echo $login; ?></li>
                                                <li><a href="logout.php">[<?php echo $l['menu']['logout'];?>]</a></li>

                                </ul>
								
                </div>

