/***********************************************************************
 * setFocus
 * set's a focus on a specificed input field
 ***********************************************************************/
function setFocus() {
        document.signup.firstname.focus();
}
